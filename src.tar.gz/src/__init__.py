"""Paquete principal del sistema de control"""
