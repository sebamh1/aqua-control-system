"""
Cliente AWS IoT Core para publicación de datos
"""
import logging
import json
import time
import threading
from typing import Optional, Callable, Dict, Any
from datetime import datetime
from pathlib import Path

try:
    from awscrt import io, mqtt
    from awsiot import mqtt_connection_builder
    AWS_SDK_AVAILABLE = True
except ImportError:
    AWS_SDK_AVAILABLE = False
    logger = logging.getLogger(__name__)
    logger.warning("AWS IoT SDK no disponible - modo standalone")

from config import AWSConfig

logger = logging.getLogger(__name__)


class AWSIoTClient:
    """
    Cliente MQTT para AWS IoT Core

    Maneja conexión, reconexión automática y publicación de datos
    """

    def __init__(self, endpoint: str = None, thing_name: str = None,
                 cert_path: str = None, key_path: str = None, ca_path: str = None,
                 region: str = None):
        self.endpoint = endpoint or AWSConfig.ENDPOINT
        self.thing_name = thing_name or AWSConfig.THING_NAME
        self.cert_path = cert_path or AWSConfig.CERT_PATH
        self.key_path = key_path or AWSConfig.KEY_PATH
        self.ca_path = ca_path or AWSConfig.CA_PATH
        self.region = region or AWSConfig.REGION

        # Estado de conexión
        self.is_connected = False
        self._connection = None
        self._lock = threading.Lock()

        # Callbacks
        self.on_connected: Optional[Callable] = None
        self.on_disconnected: Optional[Callable] = None
        self.on_message: Optional[Callable[[str, str], None]] = None

        # Buffer de mensajes offline
        self.offline_messages = []
        self.max_offline_messages = AWSConfig.MAX_OFFLINE_MESSAGES

        logger.info(f"AWSIoTClient inicializado para {self.thing_name} en {self.endpoint}")

    def connect(self) -> bool:
        """Establece conexión con AWS IoT Core"""
        if not AWS_SDK_AVAILABLE:
            logger.warning("AWS SDK no disponible - usando modo simulado")
            self.is_connected = True
            return True

        if self.is_connected:
            logger.info("Ya estamos conectados a AWS IoT")
            return True

        try:
            # Verificar que los certificados existen
            if not self._validate_certificates():
                logger.error("Certificados no encontrados o no válidos")
                return False

            # Crear evento para el loop
            event_loop_group = io.EventLoopGroup()
            host_resolver = io.DefaultHostResolver(event_loop_group)
            bootstrap = io.ClientBootstrap(event_loop_group, host_resolver)

            # Construir conexión MQTT
            self._connection = mqtt_connection_builder.mtls_from_path(
                endpoint=self.endpoint,
                cert_filepath=self.cert_path,
                pri_key_filepath=self.key_path,
                ca_filepath=self.ca_path,
                client_id=self.thing_name,
                clean_session=False,
                keep_alive_secs=AWSConfig.KEEP_ALIVE_INTERVAL_SECONDS,
                client_bootstrap=bootstrap,
            )

            # Conectar con callbacks
            connect_future = self._connection.connect()
            connect_future.result(timeout=AWSConfig.CONNECT_TIMEOUT_SECONDS)

            self.is_connected = True

            # Suscribirse a topics de comando
            self._subscribe_to_topics()

            # Publicar mensajes pendientes
            self._publish_offline_messages()

            # Callback de conexión
            if self.on_connected:
                self.on_connected()

            logger.info(f"Conectado exitosamente a AWS IoT Core ({self.endpoint})")
            return True

        except Exception as e:
            logger.error(f"Error conectando a AWS IoT Core: {e}")
            self.is_connected = False
            return False

    def disconnect(self) -> bool:
        """Desconecta de AWS IoT Core"""
        if not self.is_connected:
            return True

        try:
            if self._connection:
                disconnect_future = self._connection.disconnect()
                disconnect_future.result(timeout=5)

            self.is_connected = False

            if self.on_disconnected:
                self.on_disconnected()

            logger.info("Desconectado de AWS IoT Core")
            return True

        except Exception as e:
            logger.error(f"Error desconectando de AWS IoT Core: {e}")
            return False

    def publish_telemetry(self, payload: Dict[str, Any],
                         topic: str = None) -> bool:
        """
        Publica datos de telemetría

        Args:
            payload: Diccionario con datos a publicar
            topic: Topic MQTT (default: telemetry)
        """
        if not topic:
            topic = AWSConfig.TELEMETRY_TOPIC

        return self._publish(topic, payload)

    def publish_experiment_status(self, experiment_id: str, status: str,
                                 data: Dict[str, Any] = None) -> bool:
        """Publica estado de un experimento"""
        payload = {
            "experiment_id": experiment_id,
            "status": status,
            "timestamp": datetime.utcnow().isoformat(),
            "data": data or {}
        }

        topic = AWSConfig.EXPERIMENT_TOPIC
        return self._publish(topic, payload)

    def update_device_shadow(self, desired_state: Dict = None,
                            reported_state: Dict = None) -> bool:
        """Actualiza el Device Shadow"""
        shadow_update = {}

        if desired_state:
            shadow_update["desired"] = desired_state

        if reported_state:
            shadow_update["reported"] = reported_state

        if not shadow_update:
            return False

        shadow_topic = f"$aws/things/{self.thing_name}/shadow/update"

        return self._publish(shadow_topic, shadow_update)

    def subscribe_to_commands(self, callback: Callable[[str], None]) -> bool:
        """Se suscribe a topic de comandos"""
        if not AWS_SDK_AVAILABLE:
            logger.debug("AWS SDK no disponible - subscripción simulada")
            return True

        if not self.is_connected:
            logger.error("No conectado a AWS IoT Core")
            return False

        try:
            topic = AWSConfig.COMMAND_TOPIC

            def message_handler(topic, payload, dup, qos, retain, **kwargs):
                try:
                    command = json.loads(payload.decode('utf-8'))
                    callback(command)
                except Exception as e:
                    logger.error(f"Error procesando comando: {e}")

            subscribe_future = self._connection.subscribe(
                topic=topic,
                qos=mqtt.QoS.AT_LEAST_ONCE,
                callback=message_handler
            )
            subscribe_future.result(timeout=5)

            logger.info(f"Suscrito a topic de comandos: {topic}")
            return True

        except Exception as e:
            logger.error(f"Error suscribiéndose a comandos: {e}")
            return False

    def _publish(self, topic: str, payload: Dict[str, Any]) -> bool:
        """Publica un mensaje MQTT"""
        if not AWS_SDK_AVAILABLE:
            logger.debug(f"[SIMULATED] Publicando a {topic}: {json.dumps(payload)}")
            return True

        with self._lock:
            try:
                if not self.is_connected:
                    logger.warning(f"No conectado - almacenando mensaje para {topic}")
                    self._buffer_message(topic, payload)
                    return False

                payload_json = json.dumps(payload).encode('utf-8')

                publish_future = self._connection.publish(
                    topic=topic,
                    payload=payload_json,
                    qos=mqtt.QoS.AT_LEAST_ONCE,
                )

                publish_future.result(timeout=2)
                logger.debug(f"Publicado a {topic}: {len(payload_json)} bytes")
                return True

            except Exception as e:
                logger.error(f"Error publicando a {topic}: {e}")
                self._buffer_message(topic, payload)
                return False

    def _publish_offline_messages(self):
        """Publica mensajes que se almacenaron cuando estaba offline"""
        if not self.offline_messages:
            return

        logger.info(f"Publicando {len(self.offline_messages)} mensajes almacenados")

        for topic, payload in self.offline_messages:
            try:
                self._publish(topic, payload)
                time.sleep(0.1)  # Pequeño delay entre mensajes
            except Exception as e:
                logger.error(f"Error publicando mensaje offline: {e}")

        self.offline_messages.clear()

    def _buffer_message(self, topic: str, payload: Dict):
        """Almacena un mensaje para publicación posterior"""
        if len(self.offline_messages) >= self.max_offline_messages:
            logger.warning(f"Buffer de mensajes lleno - descartando mensaje antiguo")
            self.offline_messages.pop(0)

        self.offline_messages.append((topic, payload))
        logger.debug(f"Mensaje almacenado ({len(self.offline_messages)}/{self.max_offline_messages})")

    def _subscribe_to_topics(self):
        """Se suscribe a los topics necesarios"""
        if not self._connection:
            return

        try:
            # Suscribirse a comandos
            command_topic = AWSConfig.COMMAND_TOPIC

            def handle_command(topic, payload, dup, qos, retain, **kwargs):
                try:
                    command = json.loads(payload.decode('utf-8'))
                    if self.on_message:
                        self.on_message(topic, command)
                except Exception as e:
                    logger.error(f"Error procesando mensaje: {e}")

            subscribe_future = self._connection.subscribe(
                topic=command_topic,
                qos=mqtt.QoS.AT_LEAST_ONCE,
                callback=handle_command
            )
            subscribe_future.result(timeout=5)

            logger.info(f"Suscrito a: {command_topic}")

        except Exception as e:
            logger.error(f"Error suscribiéndose a topics: {e}")

    def _validate_certificates(self) -> bool:
        """Valida que los certificados existen"""
        cert_files = [self.cert_path, self.key_path, self.ca_path]

        for cert_file in cert_files:
            if not Path(cert_file).exists():
                logger.error(f"Certificado no encontrado: {cert_file}")
                return False

        logger.debug("Certificados validados correctamente")
        return True


class AWSIoTClientSimulated(AWSIoTClient):
    """
    Cliente simulado para testing sin AWS SDK
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        logger.info("Usando cliente AWS IoT simulado")

    def connect(self) -> bool:
        self.is_connected = True
        if self.on_connected:
            self.on_connected()
        logger.info("Conexión simulada establecida")
        return True

    def disconnect(self) -> bool:
        self.is_connected = False
        if self.on_disconnected:
            self.on_disconnected()
        return True

    def _publish(self, topic: str, payload: Dict[str, Any]) -> bool:
        logger.info(f"[SIMULATED PUBLISH] {topic}: {json.dumps(payload, indent=2)}")
        return True
