"""
Gestor de conexiones seriales con ESP32
Maneja comunicación bidireccional con protección de threading
"""
import logging
import threading
import queue
from typing import Optional, Callable, Dict, List
from dataclasses import dataclass
from enum import Enum
import serial
from serial.tools import list_ports
import time
from tenacity import retry, wait_exponential, stop_after_attempt

logger = logging.getLogger(__name__)


class DeviceType(Enum):
    """Tipos de dispositivos ESP32"""
    SENSOR_READER = 0x01     # ESP32-S3 con sensores RS485
    RELAY_CONTROLLER = 0x02  # ESP32 con relés


@dataclass
class DeviceInfo:
    """Información de un dispositivo conectado"""
    device_type: DeviceType
    port: str
    baudrate: int
    is_connected: bool = False
    last_communication: Optional[float] = None


@dataclass
class Frame:
    """Frame de comunicación serial"""
    device_id: int
    command: int
    payload: bytes
    checksum: int

    def to_bytes(self) -> bytes:
        """Convierte el frame a bytes para envío"""
        data = bytes([0xAA, 0xBB, self.device_id, self.command, len(self.payload)])
        data += self.payload
        data += self.checksum.to_bytes(2, byteorder='big')
        return data

    @staticmethod
    def from_bytes(data: bytes) -> Optional['Frame']:
        """Convierte bytes a Frame"""
        if len(data) < 6:
            return None
        if data[0] != 0xAA or data[1] != 0xBB:
            return None

        device_id = data[2]
        command = data[3]
        payload_len = data[4]

        if len(data) < 5 + payload_len + 2:
            return None

        payload = data[5:5+payload_len]
        checksum = int.from_bytes(data[5+payload_len:7+payload_len], byteorder='big')

        frame = Frame(device_id, command, payload, checksum)
        if frame.calculate_checksum() == checksum:
            return frame
        return None

    def calculate_checksum(self) -> int:
        """Calcula CRC16 del frame"""
        data = bytes([self.device_id, self.command, len(self.payload)])
        data += self.payload
        return self._crc16(data)

    @staticmethod
    def _crc16(data: bytes) -> int:
        """CRC16-CCITT"""
        crc = 0xFFFF
        for byte in data:
            crc ^= byte << 8
            for _ in range(8):
                crc <<= 1
                if crc & 0x10000:
                    crc ^= 0x1021
                crc &= 0xFFFF
        return crc


class SerialManager:
    """Gestor centralizado de conexiones seriales"""

    def __init__(self, sensor_port: str, relay_port: str,
                 baudrate: int = 115200, timeout: float = 2.0):
        self.sensor_port = sensor_port
        self.relay_port = relay_port
        self.baudrate = baudrate
        self.timeout = timeout

        # Conexiones seriales
        self.sensor_serial: Optional[serial.Serial] = None
        self.relay_serial: Optional[serial.Serial] = None

        # Threading
        self.lock = threading.Lock()
        self.reader_threads: Dict[str, threading.Thread] = {}
        self.running = False

        # Callbacks
        self.on_frame_received: Dict[int, Callable[[Frame], None]] = {}
        self.on_connection_lost: Dict[int, Callable[[], None]] = {}
        self.on_connection_gained: Dict[int, Callable[[], None]] = {}

        # Queues para comunicación
        self.response_queues: Dict[int, queue.Queue] = {
            DeviceType.SENSOR_READER.value: queue.Queue(maxsize=10),
            DeviceType.RELAY_CONTROLLER.value: queue.Queue(maxsize=10),
        }

        # Estado de dispositivos
        self.devices: Dict[int, DeviceInfo] = {}

        logger.info("SerialManager inicializado")

    def connect(self) -> bool:
        """Establece conexiones con ambas ESP32"""
        with self.lock:
            try:
                # Conectar ESP32 de sensores
                if not self._connect_device(self.sensor_port, DeviceType.SENSOR_READER):
                    logger.error(f"Falló conexión con sensores en {self.sensor_port}")
                    return False

                # Conectar ESP32 de relés
                if not self._connect_device(self.relay_port, DeviceType.RELAY_CONTROLLER):
                    logger.error(f"Falló conexión con relés en {self.relay_port}")
                    # No es crítico si falla relés
                    pass

                self.running = True
                logger.info("Conexiones seriales establecidas")
                return True

            except Exception as e:
                logger.error(f"Error al conectar: {e}")
                return False

    def _connect_device(self, port: str, device_type: DeviceType) -> bool:
        """Conecta un dispositivo específico"""
        try:
            ser = serial.Serial(
                port=port,
                baudrate=self.baudrate,
                timeout=self.timeout,
                write_timeout=self.timeout
            )
            ser.reset_input_buffer()
            ser.reset_output_buffer()

            device_id = device_type.value
            self.devices[device_id] = DeviceInfo(
                device_type=device_type,
                port=port,
                baudrate=self.baudrate,
                is_connected=True
            )

            if device_type == DeviceType.SENSOR_READER:
                self.sensor_serial = ser
            else:
                self.relay_serial = ser

            # Iniciar thread de lectura
            reader_thread = threading.Thread(
                target=self._read_loop,
                args=(device_id, ser),
                daemon=True,
                name=f"SerialReader-{device_type.name}"
            )
            reader_thread.start()
            self.reader_threads[device_type.name] = reader_thread

            # Callback de conexión
            if device_id in self.on_connection_gained:
                self.on_connection_gained[device_id]()

            logger.info(f"Conectado a {device_type.name} en {port}")
            return True

        except Exception as e:
            logger.error(f"Error conectando {device_type.name}: {e}")
            return False

    def disconnect(self) -> bool:
        """Desconecta ambas ESP32"""
        with self.lock:
            self.running = False

            # Cerrar conexiones
            for ser in [self.sensor_serial, self.relay_serial]:
                if ser and ser.is_open:
                    try:
                        ser.close()
                    except Exception as e:
                        logger.error(f"Error cerrando puerto: {e}")

            self.sensor_serial = None
            self.relay_serial = None

            logger.info("Desconectado de dispositivos seriales")
            return True

    def send_command(self, device_id: int, command: int,
                     payload: bytes = b'') -> bool:
        """Envía un comando a un dispositivo"""
        if device_id not in self.devices:
            logger.error(f"Dispositivo {device_id} no existe")
            return False

        try:
            frame = Frame(
                device_id=device_id,
                command=command,
                payload=payload,
                checksum=0
            )
            frame.checksum = frame.calculate_checksum()

            ser = self._get_serial_for_device(device_id)
            if not ser or not ser.is_open:
                logger.error(f"Puerto serial no disponible para dispositivo {device_id}")
                return False

            with self.lock:
                ser.write(frame.to_bytes())
                ser.flush()

            # Actualizar timestamp de comunicación
            self.devices[device_id].last_communication = time.time()
            logger.debug(f"Comando enviado a dispositivo {device_id}: cmd={command}")
            return True

        except Exception as e:
            logger.error(f"Error enviando comando: {e}")
            return False

    def read_response(self, device_id: int, timeout: float = 2.0) -> Optional[Frame]:
        """Lee respuesta de un dispositivo"""
        try:
            queue_obj = self.response_queues.get(device_id)
            if not queue_obj:
                return None

            return queue_obj.get(timeout=timeout)

        except queue.Empty:
            logger.warning(f"Timeout esperando respuesta de dispositivo {device_id}")
            return None
        except Exception as e:
            logger.error(f"Error leyendo respuesta: {e}")
            return None

    def _read_loop(self, device_id: int, ser: serial.Serial):
        """Loop de lectura para un dispositivo (corre en thread separado)"""
        buffer = b''
        read_timeout_count = 0

        while self.running:
            try:
                if not ser.is_open:
                    logger.warning(f"Puerto {device_id} cerrado, reconectando...")
                    if device_id in self.on_connection_lost:
                        self.on_connection_lost[device_id]()
                    break

                # Intentar leer datos
                data = ser.read(256)
                if data:
                    read_timeout_count = 0
                    buffer += data

                    # Procesar frames completos
                    while len(buffer) >= 7:
                        if buffer[0] != 0xAA:
                            buffer = buffer[1:]
                            continue

                        # Buscar fin de frame
                        payload_len = buffer[4] if len(buffer) > 4 else 0
                        frame_size = 7 + payload_len

                        if len(buffer) < frame_size:
                            break

                        frame_data = buffer[:frame_size]
                        buffer = buffer[frame_size:]

                        frame = Frame.from_bytes(frame_data)
                        if frame:
                            # Enqueue respuesta
                            if frame.device_id in self.response_queues:
                                try:
                                    self.response_queues[frame.device_id].put_nowait(frame)
                                except queue.Full:
                                    logger.warning(f"Queue lleno para dispositivo {frame.device_id}")

                            # Callback
                            if frame.device_id in self.on_frame_received:
                                self.on_frame_received[frame.device_id](frame)
                else:
                    read_timeout_count += 1
                    if read_timeout_count > 10:
                        logger.debug(f"Timeout en lectura de dispositivo {device_id}")

                time.sleep(0.01)  # Evitar busy-wait

            except Exception as e:
                logger.error(f"Error en read_loop del dispositivo {device_id}: {e}")
                time.sleep(0.1)

        logger.info(f"Read loop terminado para dispositivo {device_id}")

    def _get_serial_for_device(self, device_id: int) -> Optional[serial.Serial]:
        """Obtiene el puerto serial para un dispositivo"""
        if device_id == DeviceType.SENSOR_READER.value:
            return self.sensor_serial
        elif device_id == DeviceType.RELAY_CONTROLLER.value:
            return self.relay_serial
        return None

    def get_connected_devices(self) -> List[DeviceInfo]:
        """Retorna lista de dispositivos conectados"""
        return [d for d in self.devices.values() if d.is_connected]

    def is_device_connected(self, device_id: int) -> bool:
        """Verifica si un dispositivo está conectado"""
        return device_id in self.devices and self.devices[device_id].is_connected

    @staticmethod
    def find_available_ports() -> List[str]:
        """Encuentra puertos seriales disponibles"""
        ports = [port.device for port in list_ports.comports()]
        logger.info(f"Puertos disponibles: {ports}")
        return ports
