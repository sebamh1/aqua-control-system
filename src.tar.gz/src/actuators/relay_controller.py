"""
Controlador de relés para electroválvulas NC
"""
import logging
import time
import struct
from typing import Optional, List
from dataclasses import dataclass
from enum import Enum

from src.hardware.serial_manager import SerialManager, DeviceType
from config import ActuatorConfig

logger = logging.getLogger(__name__)


class RelayState(Enum):
    """Estado de un relé"""
    OPEN = 1      # Válvula NC abierta (relé activado)
    CLOSED = 0    # Válvula NC cerrada (relé desactivado)
    UNKNOWN = -1


@dataclass
class RelayStatus:
    """Estado de un relé"""
    relay_id: int
    state: RelayState
    last_change: Optional[float] = None
    is_responding: bool = True
    error_message: Optional[str] = None


class RelayController:
    """
    Controlador de relés para electroválvulas normalmente cerradas (NC)

    Lógica:
    - Relé ACTIVADO → Válvula ABIERTA (permite flujo de gas)
    - Relé DESACTIVADO → Válvula CERRADA (bloquea flujo)

    Protocolo:
    - CMD 0x10: ACTIVATE_RELAY (payload: relay_id)
    - CMD 0x11: DEACTIVATE_RELAY (payload: relay_id)
    - CMD 0x12: GET_RELAY_STATUS (payload: relay_id)
    """

    CMD_ACTIVATE = 0x10
    CMD_DEACTIVATE = 0x11
    CMD_GET_STATUS = 0x12
    CMD_PULSE = 0x13

    def __init__(self, serial_manager: SerialManager, num_relays: int = 2):
        self.serial_manager = serial_manager
        self.num_relays = num_relays

        # Estado de relés
        self.relay_states: dict[int, RelayStatus] = {
            i: RelayStatus(relay_id=i, state=RelayState.UNKNOWN)
            for i in range(1, num_relays + 1)
        }

        # Historial de cambios
        self.change_log: List[dict] = []

        logger.info(f"RelayController inicializado con {num_relays} relés")

    def activate_relay(self, relay_id: int) -> bool:
        """Activa un relé (abre válvula NC)"""
        if not self._validate_relay_id(relay_id):
            return False

        try:
            payload = struct.pack('B', relay_id)

            if not self.serial_manager.send_command(
                DeviceType.RELAY_CONTROLLER.value,
                self.CMD_ACTIVATE,
                payload
            ):
                logger.error(f"No se pudo enviar comando ACTIVATE para relé {relay_id}")
                self.relay_states[relay_id].is_responding = False
                return False

            # Esperar confirmación
            frame = self.serial_manager.read_response(
                DeviceType.RELAY_CONTROLLER.value,
                timeout=1.0
            )

            if frame is None:
                logger.error(f"Timeout en confirmación de ACTIVATE para relé {relay_id}")
                self.relay_states[relay_id].is_responding = False
                return False

            # Actualizar estado
            self.relay_states[relay_id].state = RelayState.OPEN
            self.relay_states[relay_id].last_change = time.time()
            self.relay_states[relay_id].is_responding = True

            self._log_change(relay_id, RelayState.OPEN)
            logger.info(f"Relé {relay_id} ACTIVADO (válvula ABIERTA)")

            return True

        except Exception as e:
            logger.error(f"Error activando relé {relay_id}: {e}")
            return False

    def deactivate_relay(self, relay_id: int) -> bool:
        """Desactiva un relé (cierra válvula NC)"""
        if not self._validate_relay_id(relay_id):
            return False

        try:
            payload = struct.pack('B', relay_id)

            if not self.serial_manager.send_command(
                DeviceType.RELAY_CONTROLLER.value,
                self.CMD_DEACTIVATE,
                payload
            ):
                logger.error(f"No se pudo enviar comando DEACTIVATE para relé {relay_id}")
                self.relay_states[relay_id].is_responding = False
                return False

            # Esperar confirmación
            frame = self.serial_manager.read_response(
                DeviceType.RELAY_CONTROLLER.value,
                timeout=1.0
            )

            if frame is None:
                logger.error(f"Timeout en confirmación de DEACTIVATE para relé {relay_id}")
                self.relay_states[relay_id].is_responding = False
                return False

            # Actualizar estado
            self.relay_states[relay_id].state = RelayState.CLOSED
            self.relay_states[relay_id].last_change = time.time()
            self.relay_states[relay_id].is_responding = True

            self._log_change(relay_id, RelayState.CLOSED)
            logger.info(f"Relé {relay_id} DESACTIVADO (válvula CERRADA)")

            return True

        except Exception as e:
            logger.error(f"Error desactivando relé {relay_id}: {e}")
            return False

    def get_relay_status(self, relay_id: int) -> Optional[RelayStatus]:
        """Obtiene el estado de un relé"""
        if not self._validate_relay_id(relay_id):
            return None

        try:
            payload = struct.pack('B', relay_id)

            if not self.serial_manager.send_command(
                DeviceType.RELAY_CONTROLLER.value,
                self.CMD_GET_STATUS,
                payload
            ):
                self.relay_states[relay_id].is_responding = False
                return self.relay_states[relay_id]

            # Esperar respuesta
            frame = self.serial_manager.read_response(
                DeviceType.RELAY_CONTROLLER.value,
                timeout=1.0
            )

            if frame is None:
                self.relay_states[relay_id].is_responding = False
                return self.relay_states[relay_id]

            # Parsear respuesta
            if len(frame.payload) >= 2:
                state_byte = frame.payload[0]
                state = RelayState(state_byte) if state_byte in [0, 1] else RelayState.UNKNOWN

                self.relay_states[relay_id].state = state
                self.relay_states[relay_id].is_responding = True

                logger.debug(f"Estado del relé {relay_id}: {state.name}")

            return self.relay_states[relay_id]

        except Exception as e:
            logger.error(f"Error obteniendo estado de relé {relay_id}: {e}")
            self.relay_states[relay_id].is_responding = False
            return self.relay_states[relay_id]

    def pulse_relay(self, relay_id: int, duration_ms: int = 100) -> bool:
        """
        Activa un relé por un tiempo determinado (pulso)
        Útil para válvulas solenoide que requieren control temporal
        """
        if not self._validate_relay_id(relay_id):
            return False

        try:
            payload = struct.pack('>BH', relay_id, duration_ms)

            if not self.serial_manager.send_command(
                DeviceType.RELAY_CONTROLLER.value,
                self.CMD_PULSE,
                payload
            ):
                logger.error(f"No se pudo enviar comando PULSE para relé {relay_id}")
                return False

            logger.info(f"Pulso enviado a relé {relay_id} ({duration_ms}ms)")
            return True

        except Exception as e:
            logger.error(f"Error en pulso de relé {relay_id}: {e}")
            return False

    def get_all_statuses(self) -> dict[int, RelayStatus]:
        """Obtiene estado de todos los relés"""
        statuses = {}
        for relay_id in self.relay_states.keys():
            status = self.get_relay_status(relay_id)
            if status:
                statuses[relay_id] = status
        return statuses

    def _validate_relay_id(self, relay_id: int) -> bool:
        """Valida que relay_id sea válido"""
        if relay_id not in self.relay_states:
            logger.error(f"ID de relé inválido: {relay_id}")
            return False
        return True

    def _log_change(self, relay_id: int, new_state: RelayState):
        """Registra cambio de estado"""
        self.change_log.append({
            "timestamp": time.time(),
            "relay_id": relay_id,
            "state": new_state.name
        })

        # Mantener solo últimos 1000 registros
        if len(self.change_log) > 1000:
            self.change_log = self.change_log[-1000:]
