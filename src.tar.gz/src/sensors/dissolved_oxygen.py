"""
Sensor de oxígeno disuelto - Modbus RTU sobre RS485
"""
import logging
import struct
from typing import Optional, Dict, Tuple
from dataclasses import dataclass
from datetime import datetime
import math

from src.hardware.serial_manager import SerialManager, Frame, DeviceType
from config import SensorConfig

logger = logging.getLogger(__name__)


@dataclass
class SensorReading:
    """Lectura de sensor"""
    timestamp: datetime
    raw_o2: float          # mg/L (lectura cruda)
    o2_compensated: float  # mg/L (compensada por salinidad)
    temperature: float     # °C
    saturation: float      # % saturación
    salinity: float        # PSU (Practical Salinity Units)
    is_valid: bool = True
    error_message: Optional[str] = None


class DissolvedOxygenSensor:
    """
    Driver para sensor de oxígeno disuelto Modbus RTU

    Protocolo Modbus:
    - Register 40001: Oxígeno disuelto (mg/L) - formato float (2 registros)
    - Register 40003: Temperatura (°C) - formato float (2 registros)
    - Register 40005: Saturación (%) - formato float (2 registros)
    """

    # Registros Modbus (direcciones holding)
    REG_O2_DISSOLVED = 40001
    REG_TEMPERATURE = 40003
    REG_SATURATION = 40005
    REG_CALIBRATION = 40007

    # Comandos
    CMD_READ_O2 = 0x01
    CMD_READ_TEMP = 0x02
    CMD_CALIBRATE = 0x03
    CMD_STATUS = 0x04

    def __init__(self, slave_id: int, serial_manager: SerialManager,
                 name: str = "DissolvedOxygen"):
        self.slave_id = slave_id
        self.serial_manager = serial_manager
        self.name = name

        # Calibración
        self.calibration_data = {
            "zero_point": 0.0,
            "span_point": SensorConfig.SENSOR_1_CALIBRATION["span_point"],
            "zero_offset": 0.0,
        }

        # Última lectura válida (para recuperación de errores)
        self.last_valid_reading: Optional[SensorReading] = None

        logger.info(f"Sensor {name} (ID:{slave_id}) inicializado")

    def read_raw(self) -> Optional[SensorReading]:
        """Lee datos crudos del sensor"""
        try:
            # Leer oxígeno disuelto
            o2_data = self._read_modbus_float(self.REG_O2_DISSOLVED)
            if o2_data is None:
                return self._create_error_reading("No se pudo leer O2")

            # Leer temperatura
            temp_data = self._read_modbus_float(self.REG_TEMPERATURE)
            if temp_data is None:
                return self._create_error_reading("No se pudo leer temperatura")

            # Leer saturación
            sat_data = self._read_modbus_float(self.REG_SATURATION)
            if sat_data is None:
                return self._create_error_reading("No se pudo leer saturación")

            # Validar rangos
            if not self._validate_ranges(o2_data, temp_data):
                return self._create_error_reading("Datos fuera de rango")

            reading = SensorReading(
                timestamp=datetime.now(),
                raw_o2=o2_data,
                o2_compensated=o2_data,
                temperature=temp_data,
                saturation=sat_data,
                salinity=0.0,  # Se actualiza con compensación
                is_valid=True
            )

            self.last_valid_reading = reading
            logger.debug(f"{self.name}: O2={o2_data:.2f} mg/L, Temp={temp_data:.2f}°C, Sat={sat_data:.2f}%")
            return reading

        except Exception as e:
            logger.error(f"Error leyendo sensor {self.name}: {e}")
            return self._create_error_reading(str(e))

    def read_compensated(self, salinity: float = 0.0, temperature: Optional[float] = None) -> Optional[SensorReading]:
        """Lee datos con compensación por salinidad"""
        reading = self.read_raw()
        if reading is None or not reading.is_valid:
            return reading

        # Usar temperatura de sensor si no se proporciona
        if temperature is None:
            temperature = reading.temperature

        # Aplicar compensación por salinidad
        try:
            reading.salinity = salinity
            reading.o2_compensated = self._apply_salinity_compensation(
                reading.raw_o2,
                temperature,
                salinity
            )
            logger.debug(f"{self.name}: O2 compensado={reading.o2_compensated:.2f} mg/L (salinidad={salinity:.2f} PSU)")
            return reading

        except Exception as e:
            logger.error(f"Error en compensación de salinidad: {e}")
            reading.is_valid = False
            reading.error_message = f"Error en compensación: {e}"
            return reading

    def calibrate(self, zero_point: float, span_point: float) -> bool:
        """Calibra el sensor con dos puntos"""
        try:
            self.calibration_data["zero_point"] = zero_point
            self.calibration_data["span_point"] = span_point

            # Enviar comando de calibración a sensor
            payload = self._encode_calibration(zero_point, span_point)
            if not self.serial_manager.send_command(
                DeviceType.SENSOR_READER.value,
                self.CMD_CALIBRATE,
                payload
            ):
                logger.error(f"No se pudo enviar comando de calibración")
                return False

            # Esperar respuesta
            frame = self.serial_manager.read_response(DeviceType.SENSOR_READER.value, timeout=3.0)
            if frame is None:
                logger.error(f"Timeout en respuesta de calibración")
                return False

            logger.info(f"{self.name} calibrado exitosamente")
            return True

        except Exception as e:
            logger.error(f"Error en calibración: {e}")
            return False

    def get_status(self) -> Dict:
        """Obtiene estado del sensor"""
        return {
            "name": self.name,
            "slave_id": self.slave_id,
            "is_connected": self.serial_manager.is_device_connected(DeviceType.SENSOR_READER.value),
            "last_reading": self.last_valid_reading,
            "calibration": self.calibration_data,
        }

    def _read_modbus_float(self, register: int) -> Optional[float]:
        """Lee un registro float (2 registros) del sensor via Modbus"""
        try:
            # Crear payload: slave_id (1 byte) + register (2 bytes)
            payload = struct.pack('>HH', register, 2)  # Address, quantity

            if not self.serial_manager.send_command(
                DeviceType.SENSOR_READER.value,
                self.CMD_READ_O2,
                payload
            ):
                return None

            # Leer respuesta
            frame = self.serial_manager.read_response(DeviceType.SENSOR_READER.value, timeout=2.0)
            if frame is None:
                return None

            # Payload: 4 bytes para float (big-endian)
            if len(frame.payload) >= 4:
                value = struct.unpack('>f', frame.payload[:4])[0]
                return value

            return None

        except Exception as e:
            logger.error(f"Error leyendo Modbus: {e}")
            return None

    def _apply_salinity_compensation(self, o2_mg_l: float,
                                    temperature_c: float,
                                    salinity_psu: float) -> float:
        """
        Aplica compensación por salinidad usando ecuación de Weiss (1970)

        ln(DO) = A1 + A2(100/T) + A3*ln(T/100) + S(B1 + B2*T + B3*T²)

        Donde:
        - T: Temperatura absoluta (Kelvin)
        - S: Salinidad (PSU)
        - DO: Oxígeno disuelto (mg/L)
        """
        try:
            # Conversión a Kelvin
            T_K = temperature_c + 273.15

            # Coeficientes de Weiss
            A1 = SensorConfig.WEISS_COEFFICIENTS["A1"]
            A2 = SensorConfig.WEISS_COEFFICIENTS["A2"]
            A3 = SensorConfig.WEISS_COEFFICIENTS["A3"]
            B1 = SensorConfig.WEISS_COEFFICIENTS["B1"]
            B2 = SensorConfig.WEISS_COEFFICIENTS["B2"]
            B3 = SensorConfig.WEISS_COEFFICIENTS["B3"]

            # Calcular ln(DO_0) para agua dulce
            ln_DO = (A1 +
                    A2 * (100 / T_K) +
                    A3 * math.log(T_K / 100) +
                    salinity_psu * (B1 + B2 * temperature_c + B3 * temperature_c**2))

            # DO_0 en ml/L, convertir a mg/L (densidad O2: 1.429 mg/ml)
            DO_ml_l = math.exp(ln_DO)
            DO_mg_l = DO_ml_l * 1.429

            # Aplicar calibración
            if self.calibration_data["span_point"] > 0:
                DO_mg_l = (o2_mg_l * DO_mg_l) / self.calibration_data["span_point"]

            return DO_mg_l

        except Exception as e:
            logger.error(f"Error en cálculo de compensación: {e}")
            return o2_mg_l  # Retornar lectura sin compensar

    def _validate_ranges(self, o2: float, temp: float) -> bool:
        """Valida que las lecturas estén dentro de rangos aceptables"""
        checks = [
            (SensorConfig.O2_MIN <= o2 <= SensorConfig.O2_MAX, f"O2={o2} fuera de rango"),
            (SensorConfig.TEMP_MIN <= temp <= SensorConfig.TEMP_MAX, f"Temp={temp} fuera de rango"),
        ]

        for check, msg in checks:
            if not check:
                logger.warning(f"{self.name}: {msg}")
                return False

        return True

    def _create_error_reading(self, error_msg: str) -> SensorReading:
        """Crea una lectura de error"""
        return SensorReading(
            timestamp=datetime.now(),
            raw_o2=0.0,
            o2_compensated=0.0,
            temperature=0.0,
            saturation=0.0,
            salinity=0.0,
            is_valid=False,
            error_message=error_msg
        )

    @staticmethod
    def _encode_calibration(zero: float, span: float) -> bytes:
        """Codifica datos de calibración para envío"""
        return struct.pack('>ff', zero, span)
