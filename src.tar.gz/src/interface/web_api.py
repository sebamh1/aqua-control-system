"""
API REST con FastAPI para gestión del sistema de control de O2
"""
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime
import json
from pathlib import Path

from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator

from config import WebAPIConfig, DATA_DIR

logger = logging.getLogger(__name__)


# ===== Modelos Pydantic =====

class SensorReadingResponse(BaseModel):
    """Respuesta de lectura de sensor"""
    timestamp: datetime
    raw_o2: float = Field(..., description="Oxígeno disuelto mg/L")
    o2_compensated: float = Field(..., description="O2 compensado por salinidad")
    temperature: float = Field(..., description="Temperatura en °C")
    saturation: float = Field(..., description="Saturación en %")
    salinity: float = Field(..., description="Salinidad en PSU")
    is_valid: bool


class ExperimentSaturationProfile(BaseModel):
    """Perfil de saturación para experimento"""
    target_saturation: float = Field(..., ge=0, le=100, description="Saturación objetivo %")
    duration_seconds: int = Field(..., gt=0, description="Duración en segundos")

    @validator('duration_seconds')
    def validate_duration(cls, v):
        if v < 60:
            raise ValueError("Duración mínima es 60 segundos")
        if v > 86400:
            raise ValueError("Duración máxima es 24 horas")
        return v


class CreateExperimentRequest(BaseModel):
    """Solicitud para crear un experimento"""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    saturation_profiles: List[ExperimentSaturationProfile] = Field(
        ..., min_items=1, max_items=5, description="1-5 perfiles de saturación"
    )
    valve_1_enabled: bool = Field(True, description="Usar válvula 1")
    valve_2_enabled: bool = Field(False, description="Usar válvula 2")


class ExperimentResponse(BaseModel):
    """Respuesta de experimento"""
    experiment_id: str
    name: str
    description: Optional[str]
    status: str  # CREATED, RUNNING, PAUSED, COMPLETED, FAILED
    created_at: datetime
    started_at: Optional[datetime]
    ended_at: Optional[datetime]
    saturation_profiles: List[ExperimentSaturationProfile]
    current_profile_index: int = 0
    current_saturation: float = 0.0
    data_points: int = 0


class ControlStateResponse(BaseModel):
    """Estado actual del control"""
    target_saturation: float
    current_saturation: float
    current_o2: float
    error: float
    action: str
    valve_1_open: bool
    valve_2_open: bool
    is_stable: bool
    stability_percentage: float


class SystemStatusResponse(BaseModel):
    """Estado del sistema"""
    is_running: bool
    aws_connected: bool
    sensor_1_connected: bool
    sensor_2_connected: bool
    relay_controller_connected: bool
    active_experiment: Optional[str]
    uptime_seconds: float
    data_points_stored: int


# ===== API =====

class AquaControlAPI:
    """Clase que encapsula la API REST"""

    def __init__(self, app: FastAPI = None):
        self.app = app or FastAPI(
            title="Aqua Control System",
            description="Sistema de control de oxígeno disuelto para acuicultura",
            version="1.0.0"
        )

        self.start_time = datetime.now()

        # Configurar CORS
        self._setup_cors()

        # Registrar rutas
        self._register_routes()

        logger.info("API inicializada")

    def _setup_cors(self):
        """Configura CORS"""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=WebAPIConfig.CORS_ORIGINS,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _register_routes(self):
        """Registra todas las rutas"""
        # Health
        self.app.get("/health", tags=["Health"])(self.health_check)

        # Sensores
        self.app.get("/api/sensors/current", tags=["Sensors"])(self.get_current_readings)
        self.app.get("/api/sensors/status", tags=["Sensors"])(self.get_sensors_status)

        # Experimentos
        self.app.get("/api/experiments", tags=["Experiments"])(self.list_experiments)
        self.app.post("/api/experiments", tags=["Experiments"])(self.create_experiment)
        self.app.get("/api/experiments/{experiment_id}", tags=["Experiments"])(self.get_experiment)
        self.app.post("/api/experiments/{experiment_id}/start", tags=["Experiments"])(self.start_experiment)
        self.app.post("/api/experiments/{experiment_id}/stop", tags=["Experiments"])(self.stop_experiment)
        self.app.post("/api/experiments/{experiment_id}/pause", tags=["Experiments"])(self.pause_experiment)
        self.app.post("/api/experiments/{experiment_id}/resume", tags=["Experiments"])(self.resume_experiment)

        # Datos
        self.app.get("/api/data/download/{experiment_id}", tags=["Data"])(self.download_experiment_data)
        self.app.get("/api/data/latest", tags=["Data"])(self.get_latest_data)

        # Control
        self.app.get("/api/control/status", tags=["Control"])(self.get_control_status)

        # Sistema
        self.app.get("/api/system/status", tags=["System"])(self.get_system_status)

    # ===== Handlers =====

    async def health_check(self):
        """Health check endpoint"""
        return {
            "status": "ok",
            "timestamp": datetime.utcnow().isoformat()
        }

    async def get_current_readings(self):
        """Obtiene lecturas actuales de sensores"""
        return {
            "sensor_1": {
                "o2": 7.5,
                "temperature": 18.2,
                "saturation": 75.3,
                "timestamp": datetime.utcnow().isoformat(),
                "is_valid": True
            },
            "sensor_2": {
                "o2": 7.4,
                "temperature": 18.1,
                "saturation": 74.8,
                "timestamp": datetime.utcnow().isoformat(),
                "is_valid": True
            }
        }

    async def get_sensors_status(self):
        """Obtiene estado de sensores"""
        return {
            "sensor_1": {
                "is_connected": True,
                "is_responding": True,
                "last_reading": datetime.utcnow().isoformat(),
                "error": None
            },
            "sensor_2": {
                "is_connected": True,
                "is_responding": True,
                "last_reading": datetime.utcnow().isoformat(),
                "error": None
            }
        }

    async def list_experiments(self):
        """Lista experimentos"""
        experiments = []

        # Leer directorio de experimentos
        exp_dir = DATA_DIR / "experiments"
        if exp_dir.exists():
            for exp_file in exp_dir.glob("*.json"):
                try:
                    with open(exp_file, 'r') as f:
                        exp = json.load(f)
                        experiments.append(exp)
                except:
                    pass

        return {
            "experiments": experiments,
            "count": len(experiments)
        }

    async def create_experiment(self, request: CreateExperimentRequest):
        """Crea un nuevo experimento"""
        from uuid import uuid4

        experiment_id = str(uuid4())

        experiment = {
            "experiment_id": experiment_id,
            "name": request.name,
            "description": request.description,
            "status": "CREATED",
            "created_at": datetime.utcnow().isoformat(),
            "started_at": None,
            "ended_at": None,
            "saturation_profiles": [
                {
                    "target_saturation": p.target_saturation,
                    "duration_seconds": p.duration_seconds
                }
                for p in request.saturation_profiles
            ],
            "valve_1_enabled": request.valve_1_enabled,
            "valve_2_enabled": request.valve_2_enabled,
            "current_profile_index": 0,
            "current_saturation": 0.0,
            "data_points": 0
        }

        # Guardar experimento
        exp_dir = DATA_DIR / "experiments"
        exp_dir.mkdir(exist_ok=True)

        exp_file = exp_dir / f"{experiment_id}.json"
        with open(exp_file, 'w') as f:
            json.dump(experiment, f, indent=2)

        logger.info(f"Experimento creado: {experiment_id}")
        return experiment

    async def get_experiment(self, experiment_id: str):
        """Obtiene detalles de un experimento"""
        exp_file = DATA_DIR / "experiments" / f"{experiment_id}.json"

        if not exp_file.exists():
            raise HTTPException(status_code=404, detail="Experimento no encontrado")

        with open(exp_file, 'r') as f:
            return json.load(f)

    async def start_experiment(self, experiment_id: str, background_tasks: BackgroundTasks):
        """Inicia un experimento"""
        experiment = await self.get_experiment(experiment_id)

        experiment["status"] = "RUNNING"
        experiment["started_at"] = datetime.utcnow().isoformat()

        # Guardar estado
        exp_file = DATA_DIR / "experiments" / f"{experiment_id}.json"
        with open(exp_file, 'w') as f:
            json.dump(experiment, f, indent=2)

        logger.info(f"Experimento iniciado: {experiment_id}")

        # Aquí iría la lógica de ejecución real
        # background_tasks.add_task(execute_experiment, experiment_id)

        return experiment

    async def stop_experiment(self, experiment_id: str):
        """Detiene un experimento"""
        experiment = await self.get_experiment(experiment_id)

        experiment["status"] = "COMPLETED"
        experiment["ended_at"] = datetime.utcnow().isoformat()

        exp_file = DATA_DIR / "experiments" / f"{experiment_id}.json"
        with open(exp_file, 'w') as f:
            json.dump(experiment, f, indent=2)

        logger.info(f"Experimento detenido: {experiment_id}")
        return experiment

    async def pause_experiment(self, experiment_id: str):
        """Pausa un experimento"""
        experiment = await self.get_experiment(experiment_id)
        experiment["status"] = "PAUSED"

        exp_file = DATA_DIR / "experiments" / f"{experiment_id}.json"
        with open(exp_file, 'w') as f:
            json.dump(experiment, f, indent=2)

        return experiment

    async def resume_experiment(self, experiment_id: str):
        """Reanuda un experimento"""
        experiment = await self.get_experiment(experiment_id)
        experiment["status"] = "RUNNING"

        exp_file = DATA_DIR / "experiments" / f"{experiment_id}.json"
        with open(exp_file, 'w') as f:
            json.dump(experiment, f, indent=2)

        return experiment

    async def download_experiment_data(self, experiment_id: str):
        """Descarga datos de experimento en CSV"""
        csv_file = DATA_DIR / "experiments" / f"{experiment_id}_data.csv"

        if not csv_file.exists():
            raise HTTPException(status_code=404, detail="Archivo de datos no encontrado")

        return FileResponse(
            path=csv_file,
            filename=f"experiment_{experiment_id}.csv",
            media_type="text/csv"
        )

    async def get_latest_data(self):
        """Obtiene últimos datos recolectados"""
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "sensor_1_o2": 7.5,
            "sensor_2_o2": 7.4,
            "average_saturation": 75.1,
            "temperature": 18.15
        }

    async def get_control_status(self):
        """Obtiene estado del control"""
        return {
            "target_saturation": 75.0,
            "current_saturation": 74.8,
            "error": 0.2,
            "action": "HOLD",
            "valve_1_open": False,
            "valve_2_open": False,
            "is_stable": True,
            "stability_percentage": 95.0
        }

    async def get_system_status(self):
        """Obtiene estado general del sistema"""
        uptime = (datetime.now() - self.start_time).total_seconds()

        return {
            "is_running": True,
            "aws_connected": True,
            "sensor_1_connected": True,
            "sensor_2_connected": True,
            "relay_controller_connected": True,
            "active_experiment": None,
            "uptime_seconds": uptime,
            "data_points_stored": 0
        }


def create_app() -> FastAPI:
    """Factory para crear la aplicación FastAPI"""
    api = AquaControlAPI()
    return api.app
