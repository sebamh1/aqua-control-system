"""
Controlador de saturación de O2 con lógica de histéresis
"""
import logging
import time
import math
from typing import Optional, List
from dataclasses import dataclass
from collections import deque
from enum import Enum

from src.actuators.relay_controller import RelayController, RelayState
from config import ControlConfig

logger = logging.getLogger(__name__)


class ControlMode(Enum):
    """Modo de control"""
    MANUAL = 1      # Control manual
    AUTO = 2        # Control automático


class ControlAction(Enum):
    """Acción de control"""
    INCREASE = 1    # Aumentar O2 (abrir válvulas)
    DECREASE = -1   # Disminuir O2 (cerrar válvulas)
    HOLD = 0        # Mantener (no hacer nada)


@dataclass
class ControlState:
    """Estado actual del control"""
    target_saturation: float
    current_saturation: float
    current_o2: float
    error: float                    # target - current
    action: ControlAction
    valve_1_open: bool
    valve_2_open: bool
    is_stable: bool = False
    stability_percentage: float = 0.0


class SaturationController:
    """
    Controlador de saturación de O2

    Estrategia de control: Histéresis adaptativa
    - Si O2 < (target - hysteresis) → ABRIR válvula (aumentar)
    - Si O2 > (target + hysteresis) → CERRAR válvula (disminuir)
    - Si O2 está en banda → MANTENER (no hacer nada)

    Histéresis = 5% del target para evitar oscilaciones
    """

    def __init__(self, relay_controller: RelayController,
                 valve_1_id: int = 1, valve_2_id: int = 2,
                 hysteresis_percent: float = None):
        self.relay_controller = relay_controller
        self.valve_1_id = valve_1_id
        self.valve_2_id = valve_2_id

        # Configuración
        self.hysteresis_percent = hysteresis_percent or ControlConfig.HYSTERESIS_PERCENT
        self.stability_window = ControlConfig.STABILITY_WINDOW_SECONDS
        self.stability_threshold = ControlConfig.STABILITY_THRESHOLD

        # Control
        self.target_saturation: float = 50.0
        self.mode = ControlMode.AUTO

        # Historial de lecturas para detección de estabilidad
        self.reading_history: deque = deque(maxlen=30)  # Últimos 30 segundos

        # Estado actual
        self.last_action_time: float = 0.0
        self.action_cooldown_seconds: float = 1.0

        # Estadísticas
        self.control_log: List[dict] = []

        logger.info(f"SaturationController inicializado (hysteresis={self.hysteresis_percent}%)")

    def set_target_saturation(self, target: float) -> bool:
        """Establece el valor objetivo de saturación"""
        if not (ControlConfig.TARGET_SATURATION_MIN <= target <= ControlConfig.TARGET_SATURATION_MAX):
            logger.error(f"Target {target} fuera de rango permitido")
            return False

        self.target_saturation = target
        logger.info(f"Target de saturación establecido a {target}%")
        return True

    def calculate_control_action(self, current_saturation: float,
                                current_o2: float = 0.0) -> ControlAction:
        """
        Calcula la acción de control basada en el valor actual

        Returns:
            ControlAction: INCREASE, DECREASE o HOLD
        """
        if not (0 <= current_saturation <= 100):
            logger.warning(f"Saturación fuera de rango: {current_saturation}%")
            current_saturation = max(0, min(100, current_saturation))

        # Calcular banda de histéresis
        hysteresis_band = self.target_saturation * self.hysteresis_percent / 100

        lower_threshold = self.target_saturation - hysteresis_band
        upper_threshold = self.target_saturation + hysteresis_band

        # Determinar acción
        if current_saturation < lower_threshold:
            action = ControlAction.INCREASE
        elif current_saturation > upper_threshold:
            action = ControlAction.DECREASE
        else:
            action = ControlAction.HOLD

        logger.debug(
            f"Control: sat={current_saturation:.1f}% target={self.target_saturation:.1f}% "
            f"[{lower_threshold:.1f}-{upper_threshold:.1f}] → {action.name}"
        )

        return action

    def apply_control_action(self, action: ControlAction) -> bool:
        """
        Aplica la acción de control activando/desactivando válvulas
        """
        # Verificar cooldown
        now = time.time()
        if now - self.last_action_time < self.action_cooldown_seconds:
            return False

        self.last_action_time = now

        try:
            if action == ControlAction.INCREASE:
                # Abrir válvulas para inyectar gas
                logger.info("ACCIÓN: Aumentar O2 → ABRIENDO válvulas")
                self.relay_controller.activate_relay(self.valve_1_id)
                # Opcionalmente, activar segundo relé si se necesita más flujo
                # self.relay_controller.activate_relay(self.valve_2_id)

            elif action == ControlAction.DECREASE:
                # Cerrar válvulas para reducir O2
                logger.info("ACCIÓN: Disminuir O2 → CERRANDO válvulas")
                self.relay_controller.deactivate_relay(self.valve_1_id)
                self.relay_controller.deactivate_relay(self.valve_2_id)

            elif action == ControlAction.HOLD:
                # Mantener estado actual (no hacer nada)
                logger.debug("ACCIÓN: Mantener estado")

            self._log_control_action(action)
            return True

        except Exception as e:
            logger.error(f"Error aplicando acción de control: {e}")
            return False

    def update(self, current_saturation: float, current_o2: float = 0.0) -> ControlState:
        """
        Actualiza el estado del controlador y retorna el estado actual

        Este método debe llamarse regularmente (cada 1 segundo típicamente)
        """
        # Agregar lectura al historial
        self.reading_history.append(current_saturation)

        # Calcular acción
        action = self.calculate_control_action(current_saturation, current_o2)

        # Aplicar acción
        if action != ControlAction.HOLD:
            self.apply_control_action(action)

        # Verificar estabilidad
        is_stable = self.is_stable()

        # Obtener estado de válvulas
        valve_1_status = self.relay_controller.get_relay_status(self.valve_1_id)
        valve_2_status = self.relay_controller.get_relay_status(self.valve_2_id)

        valve_1_open = valve_1_status.state == RelayState.OPEN if valve_1_status else False
        valve_2_open = valve_2_status.state == RelayState.OPEN if valve_2_status else False

        # Construir estado
        control_state = ControlState(
            target_saturation=self.target_saturation,
            current_saturation=current_saturation,
            current_o2=current_o2,
            error=self.target_saturation - current_saturation,
            action=action,
            valve_1_open=valve_1_open,
            valve_2_open=valve_2_open,
            is_stable=is_stable,
            stability_percentage=self.get_stability_percentage()
        )

        return control_state

    def is_stable(self) -> bool:
        """
        Verifica si el sistema está estabilizado

        Criterio: Desviación estándar < threshold durante la ventana de tiempo
        """
        if len(self.reading_history) < 10:
            return False

        try:
            readings = list(self.reading_history)

            # Calcular media y desviación estándar
            mean = sum(readings) / len(readings)
            variance = sum((x - mean) ** 2 for x in readings) / len(readings)
            std_dev = math.sqrt(variance)

            # Considerar desviación como porcentaje del target
            std_dev_percent = (std_dev / self.target_saturation * 100) if self.target_saturation > 0 else 0

            is_stable = std_dev_percent <= self.stability_threshold

            logger.debug(f"Estabilidad: std={std_dev_percent:.2f}% (threshold={self.stability_threshold}%) → {'ESTABLE' if is_stable else 'INESTABLE'}")

            return is_stable

        except Exception as e:
            logger.error(f"Error calculando estabilidad: {e}")
            return False

    def get_stability_percentage(self) -> float:
        """Retorna el porcentaje de estabilidad (0-100%)"""
        if len(self.reading_history) < 10:
            return 0.0

        try:
            readings = list(self.reading_history)
            mean = sum(readings) / len(readings)
            variance = sum((x - mean) ** 2 for x in readings) / len(readings)
            std_dev = math.sqrt(variance)

            std_dev_percent = (std_dev / self.target_saturation * 100) if self.target_saturation > 0 else 0

            # 100% cuando std = 0, 0% cuando std > threshold
            stability = max(0, 100 - (std_dev_percent / self.stability_threshold * 100))
            return min(100, stability)

        except:
            return 0.0

    def reset(self):
        """Reinicia el controlador"""
        self.reading_history.clear()
        self.last_action_time = 0.0

        # Cerrar todas las válvulas
        self.relay_controller.deactivate_relay(self.valve_1_id)
        self.relay_controller.deactivate_relay(self.valve_2_id)

        logger.info("SaturationController reiniciado")

    def _log_control_action(self, action: ControlAction):
        """Registra una acción de control"""
        self.control_log.append({
            "timestamp": time.time(),
            "action": action.name,
            "target": self.target_saturation,
        })

        # Mantener solo últimos 1000 registros
        if len(self.control_log) > 1000:
            self.control_log = self.control_log[-1000:]

    def get_metrics(self) -> dict:
        """Retorna métricas del controlador"""
        if len(self.reading_history) == 0:
            return {}

        readings = list(self.reading_history)
        mean = sum(readings) / len(readings)
        variance = sum((x - mean) ** 2 for x in readings) / len(readings)
        std_dev = math.sqrt(variance)

        return {
            "target": self.target_saturation,
            "current_mean": mean,
            "current_std": std_dev,
            "min": min(readings),
            "max": max(readings),
            "readings_count": len(readings),
            "is_stable": self.is_stable(),
            "stability_percentage": self.get_stability_percentage(),
        }
