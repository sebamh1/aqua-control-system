"""
Punto de entrada principal del sistema
"""
import logging
import sys
import signal
from typing import Optional
import uvicorn

from config import (
    SerialConfig, LoggingConfig, WebAPIConfig,
    LOGS_DIR
)
from src.interface.web_api import create_app
from src.hardware.serial_manager import SerialManager
from src.sensors.dissolved_oxygen import DissolvedOxygenSensor
from src.actuators.relay_controller import RelayController
from src.experiments.saturation_controller import SaturationController
from src.cloud.aws_iot_client import AWSIoTClient


# Configurar logging
def setup_logging():
    """Configura el sistema de logging"""
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Handler para archivo
    file_handler = logging.FileHandler(LoggingConfig.LOG_FILE)
    file_handler.setLevel(getattr(logging, LoggingConfig.LOG_LEVEL))
    file_handler.setFormatter(logging.Formatter(log_format))

    # Handler para consola
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, LoggingConfig.LOG_LEVEL))
    console_handler.setFormatter(logging.Formatter(log_format))

    # Logger raíz
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, LoggingConfig.LOG_LEVEL))
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    return logging.getLogger(__name__)


logger = setup_logging()


class AquaControlSystem:
    """
    Sistema principal de control de O2
    Integra hardware, sensores, actuadores y API web
    """

    def __init__(self):
        self.running = False
        self.serial_manager: Optional[SerialManager] = None
        self.sensor_1: Optional[DissolvedOxygenSensor] = None
        self.sensor_2: Optional[DissolvedOxygenSensor] = None
        self.relay_controller: Optional[RelayController] = None
        self.saturation_controller: Optional[SaturationController] = None
        self.aws_client: Optional[AWSIoTClient] = None

        logger.info("=== AquaControlSystem Inicializando ===")

    def initialize(self) -> bool:
        """Inicializa todos los componentes del sistema"""
        try:
            # 1. Inicializar Serial Manager
            logger.info("Inicializando Serial Manager...")
            self.serial_manager = SerialManager(
                sensor_port=SerialConfig.ESP32_SENSOR_PORT,
                relay_port=SerialConfig.ESP32_RELAY_PORT,
                baudrate=SerialConfig.BAUDRATE,
                timeout=SerialConfig.TIMEOUT
            )

            if not self.serial_manager.connect():
                logger.warning("No se pudo conectar a ESP32 - continuando en modo degradado")

            # 2. Inicializar Sensores
            logger.info("Inicializando sensores de O2...")
            from config import SensorConfig

            self.sensor_1 = DissolvedOxygenSensor(
                slave_id=SensorConfig.SENSOR_1_SLAVE_ID,
                serial_manager=self.serial_manager,
                name="Sensor O2 #1"
            )

            self.sensor_2 = DissolvedOxygenSensor(
                slave_id=SensorConfig.SENSOR_2_SLAVE_ID,
                serial_manager=self.serial_manager,
                name="Sensor O2 #2"
            )

            # 3. Inicializar Relés
            logger.info("Inicializando controlador de relés...")
            self.relay_controller = RelayController(
                serial_manager=self.serial_manager,
                num_relays=2
            )

            # 4. Inicializar Controlador de Saturación
            logger.info("Inicializando controlador de saturación...")
            self.saturation_controller = SaturationController(
                relay_controller=self.relay_controller
            )

            # 5. Inicializar Cliente AWS IoT
            logger.info("Inicializando cliente AWS IoT...")
            self.aws_client = AWSIoTClient()
            self.aws_client.connect()

            self.running = True
            logger.info("=== Sistema inicializado exitosamente ===")
            return True

        except Exception as e:
            logger.error(f"Error inicializando sistema: {e}")
            return False

    def shutdown(self):
        """Apaga el sistema ordenadamente"""
        logger.info("Apagando sistema...")

        try:
            if self.saturation_controller:
                self.saturation_controller.reset()

            if self.relay_controller:
                # Cerrar todas las válvulas
                self.relay_controller.deactivate_relay(1)
                self.relay_controller.deactivate_relay(2)

            if self.serial_manager:
                self.serial_manager.disconnect()

            if self.aws_client:
                self.aws_client.disconnect()

            self.running = False
            logger.info("Sistema apagado correctamente")

        except Exception as e:
            logger.error(f"Error durante apagado: {e}")

    def get_status(self) -> dict:
        """Retorna estado actual del sistema"""
        return {
            "is_running": self.running,
            "serial_connected": self.serial_manager.is_device_connected(1) if self.serial_manager else False,
            "aws_connected": self.aws_client.is_connected if self.aws_client else False,
            "sensor_1_ok": bool(self.sensor_1),
            "sensor_2_ok": bool(self.sensor_2),
            "relay_controller_ok": bool(self.relay_controller),
        }


# Instancia global del sistema
aqua_system: Optional[AquaControlSystem] = None


def signal_handler(sig, frame):
    """Maneja señales de cierre"""
    logger.info("Recibida señal de cierre")
    if aqua_system:
        aqua_system.shutdown()
    sys.exit(0)


def main():
    """Función principal"""
    global aqua_system

    # Registrar manejadores de señales
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        # Inicializar sistema
        aqua_system = AquaControlSystem()
        if not aqua_system.initialize():
            logger.error("Falló inicialización del sistema")
            return False

        # Crear y lanzar aplicación FastAPI
        logger.info("Iniciando servidor FastAPI...")
        app = create_app()

        # Configurar para desarrollo/producción
        if WebAPIConfig.DEBUG:
            logger.info("Ejecutando en modo DEBUG")
            uvicorn.run(
                app,
                host=WebAPIConfig.HOST,
                port=WebAPIConfig.PORT,
                log_level="debug",
                reload=True
            )
        else:
            logger.info(f"Ejecutando en modo producción ({WebAPIConfig.HOST}:{WebAPIConfig.PORT})")
            uvicorn.run(
                app,
                host=WebAPIConfig.HOST,
                port=WebAPIConfig.PORT,
                workers=WebAPIConfig.WORKERS,
                log_level="info"
            )

        return True

    except KeyboardInterrupt:
        logger.info("Interrupción del usuario")
        if aqua_system:
            aqua_system.shutdown()
        return True

    except Exception as e:
        logger.error(f"Error fatal: {e}", exc_info=True)
        if aqua_system:
            aqua_system.shutdown()
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
